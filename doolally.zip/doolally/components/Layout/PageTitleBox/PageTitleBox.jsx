import React from "react";

export default function PageTitleBox(){
    return(
        <div>
            
        </div>
    )
}